var myApp = angular.module('myApp', ['ngCookies']);

        myApp.controller('MyController', ['$scope', '$cookies','$window', function($scope, $cookies, $window) {
            
			var expireDate = new Date();
			expireDate.setTime(expireDate.getTime() + (60 * 1000));
			$scope.myCookieVal=$cookies.get('cmpid');
			console.log($scope.myCookieVal);
			$scope.setCookie=function(val) {
			$cookies.put('cmpid',val, {'expires': expireDate});		
			};
			$scope.clearCookies = function () {
                $cookies.remove('cmpid');
            };
        }]);