describe('cookie validation', function(){
  var ctrl, scope, timeout;   
  beforeEach(angular.mock.module('ngCookies', 'myApp'));   
  beforeEach(inject(function($controller, $rootScope, $cookies){    
     timeout = jasmine.createSpy('$timeout');

    scope = $rootScope.$new();
      ctrl=$controller('MyController', {$scope:scope, $cookies: $cookies, '$timeout': timeout});
	  $rootScope.$digest();
  }));

  beforeEach(function (done) {
        window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 600000;
        setTimeout(function () {
            done();
        }, 500);
    });
  
  it('sets the cookie on the scope', function(){
      expect(scope.myCookieVal).toBeUndefined();      
	  
	inject(function($cookies) {
          expect($cookies.cmpid).toBeUndefined();
		  $cookies.cmpid='hello';
		  expect($cookies.cmpid).toBe('hello');
        });
	  
  });
   
    it('should expires after 1 minute', function () {
		inject(function($cookies) {
        expect($cookies.cmpid).toBeUndefined();
		});
    });
  
});